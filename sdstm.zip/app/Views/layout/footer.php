<div class="footer clearfix mb-0 text-muted">

    <div class="float-end">
        <small>Kadek Suka Astawa &copy; 2021 | Statistik</small>
    </div>
</div>