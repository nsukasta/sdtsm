<< ? php foreach($nMax - > getResult() as $row) ? >
    <?php foreach ($nMin->getResult() as $nmin) ?>
<?php foreach ($nAvg->getResult() as $ntr) ?>